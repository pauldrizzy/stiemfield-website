import type { Metadata } from 'next'
import Link from 'next/link'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import { ArrowRight } from 'lucide-react'

export const metadata: Metadata = {
  title: 'Insights',
  description:
    'Published thinking from Stiemfield — demonstrations of the analytical capability brought to every convergence engagement.',
}

const articles = [
  {
    slug: 'introducing-the-stiem-framework',
    title: 'Introducing the STIEM Framework',
    pillar: 'Methodology',
    date: 'May 2026',
    excerpt:
      'The five forces, the two scoring dimensions, and the gap patterns that explain why transformation programmes underdeliver despite capable components.',
  },
  {
    slug: 'strategy-execution-gap-nigerian-mid-market',
    title: 'The Strategy–Execution Gap in Nigerian Mid-Market Organisations',
    pillar: 'Strategy',
    date: 'May 2026',
    excerpt:
      'The most prevalent convergence gap pattern in Nigeria: strategy is defined, execution is attempted, and the architectural gap between them is systematically ignored.',
  },
  {
    slug: 'why-digital-transformations-fail',
    title: 'Why Digital Transformations Fail (Without the Management Layer)',
    pillar: 'Technology',
    date: 'May 2026',
    excerpt:
      'Technology investment does not produce transformation outcomes on its own. The management layer that integrates the technology into how work is done is where most programmes fail.',
  },
  {
    slug: 'innovation-as-convergence-not-activity',
    title: 'Innovation as Convergence, Not Activity',
    pillar: 'Innovation',
    date: 'Coming soon',
    excerpt:
      'Why innovation activity does not produce innovation outcomes without operational integration. The Innovation–Execution gap explained.',
  },
  {
    slug: 'the-convergence-map-explained',
    title: 'The Convergence Map: What It Is and What It Is Not',
    pillar: 'Methodology',
    date: 'Coming soon',
    excerpt:
      'A walkthrough of the Fieldscan deliverable structure — what clients receive, what evidence supports it, and what they own.',
  },
  {
    slug: 'diagnostic-discipline-in-advisory',
    title: 'Diagnostic Discipline in Advisory Engagements',
    pillar: 'Execution',
    date: 'Coming soon',
    excerpt:
      'Why evidence-based diagnostic methodology produces different outcomes than consensus-based or opinion-led advisory.',
  },
  {
    slug: 'convergence-patterns-pan-african-growth',
    title: 'Convergence Patterns in Pan-African Growth-Stage Organisations',
    pillar: 'Strategy',
    date: 'Coming soon',
    excerpt:
      'Application of STIEM thinking to scaling-stage organisations across the continent.',
  },
  {
    slug: 'why-i-founded-stiemfield',
    title: 'Why I Founded Stiemfield',
    pillar: 'Founder Voice',
    date: 'Coming soon',
    excerpt:
      'The Osun State NYSC engagements, the pattern recognition, the intellectual origin of the framework, and the firm\'s institutional ambition.',
  },
]

const pillarColors: Record<string, string> = {
  Methodology: 'var(--teal)',
  Strategy: 'var(--teal)',
  Technology: 'var(--amber)',
  Innovation: '#F7BC3D',
  Execution: 'var(--teal-light)',
  Management: 'var(--navy)',
  'Founder Voice': 'var(--amber)',
}

export default function InsightsPage() {
  return (
    <>
      <Navigation />
      <main>
        {/* Page hero */}
        <div
          className="pt-36 pb-20 px-6 lg:px-12"
          style={{ background: 'var(--navy)' }}
        >
          <div className="max-w-7xl mx-auto">
            <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
              PUBLISHED THINKING
            </p>
            <h1
              className="display-heading text-white max-w-2xl"
              style={{ fontSize: 'clamp(2.2rem, 4vw, 3.4rem)' }}
            >
              Eight articles demonstrating the analytical
              <br />
              capability Stiemfield brings to every engagement.
            </h1>
          </div>
        </div>

        {/* Articles grid */}
        <div className="py-20 px-6 lg:px-12" style={{ background: 'var(--canvas)' }}>
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {articles.map((article) => {
                const isComing = article.date === 'Coming soon'
                const color = pillarColors[article.pillar] || 'var(--teal)'
                return isComing ? (
                  <div
                    key={article.slug}
                    className="flex flex-col border opacity-50"
                    style={{ borderColor: 'rgba(11,31,58,0.08)', background: 'white' }}
                  >
                    <div className="h-1" style={{ background: color }} />
                    <div className="p-7">
                      <div className="flex justify-between items-center mb-4">
                        <span
                          className="text-xs tracking-widest px-2 py-1"
                          style={{
                            fontFamily: 'var(--font-dm-mono, monospace)',
                            color,
                            background: `${color}15`,
                          }}
                        >
                          {article.pillar.toUpperCase()}
                        </span>
                        <span className="text-xs" style={{ color: 'var(--slate)', opacity: 0.5 }}>
                          {article.date}
                        </span>
                      </div>
                      <h2
                        className="font-semibold mb-3 leading-snug"
                        style={{ fontFamily: 'var(--font-cormorant, serif)', fontSize: '1.3rem', color: 'var(--navy)' }}
                      >
                        {article.title}
                      </h2>
                      <p className="text-sm leading-relaxed" style={{ color: 'var(--slate)' }}>
                        {article.excerpt}
                      </p>
                    </div>
                  </div>
                ) : (
                  <Link
                    key={article.slug}
                    href={`/insights/${article.slug}`}
                    className="group flex flex-col border transition-all duration-200"
                    style={{ borderColor: 'rgba(11,31,58,0.08)', background: 'white' }}
                    onMouseEnter={(e) => {
                      const el = e.currentTarget as HTMLElement
                      el.style.borderColor = 'var(--teal)'
                      el.style.transform = 'translateY(-2px)'
                      el.style.boxShadow = '0 8px 32px rgba(13,115,119,0.1)'
                    }}
                    onMouseLeave={(e) => {
                      const el = e.currentTarget as HTMLElement
                      el.style.borderColor = 'rgba(11,31,58,0.08)'
                      el.style.transform = 'translateY(0)'
                      el.style.boxShadow = 'none'
                    }}
                  >
                    <div className="h-1" style={{ background: color }} />
                    <div className="p-7 flex flex-col flex-1">
                      <div className="flex justify-between items-center mb-4">
                        <span
                          className="text-xs tracking-widest px-2 py-1"
                          style={{
                            fontFamily: 'var(--font-dm-mono, monospace)',
                            color,
                            background: `${color}15`,
                          }}
                        >
                          {article.pillar.toUpperCase()}
                        </span>
                        <span className="text-xs" style={{ color: 'var(--slate)', opacity: 0.5 }}>
                          {article.date}
                        </span>
                      </div>
                      <h2
                        className="font-semibold mb-3 leading-snug flex-1"
                        style={{ fontFamily: 'var(--font-cormorant, serif)', fontSize: '1.3rem', color: 'var(--navy)' }}
                      >
                        {article.title}
                      </h2>
                      <p className="text-sm leading-relaxed mb-4" style={{ color: 'var(--slate)' }}>
                        {article.excerpt}
                      </p>
                      <div
                        className="inline-flex items-center gap-2 text-xs font-medium"
                        style={{ color: 'var(--teal)' }}
                      >
                        Read Article <ArrowRight size={12} />
                      </div>
                    </div>
                  </Link>
                )
              })}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </>
  )
}
