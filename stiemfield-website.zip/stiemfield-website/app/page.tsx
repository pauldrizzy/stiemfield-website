import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import Hero from '@/components/sections/Hero'
import STIEMFramework from '@/components/sections/STIEMFramework'
import GapPatterns from '@/components/sections/GapPatterns'
import Services from '@/components/sections/Services'
import About from '@/components/sections/About'
import Geography from '@/components/sections/Geography'
import InsightsPreview from '@/components/sections/InsightsPreview'
import ContactForm from '@/components/sections/ContactForm'

export default function Home() {
  return (
    <>
      <Navigation />
      <main>
        <Hero />
        <STIEMFramework />
        <GapPatterns />
        <Services />
        <About />
        <Geography />
        <InsightsPreview />
        <ContactForm />
      </main>
      <Footer />
    </>
  )
}
