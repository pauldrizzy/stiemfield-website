import { NextRequest, NextResponse } from 'next/server'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      name,
      organisation,
      role,
      email,
      country,
      size,
      service,
      situation,
      source,
    } = body

    // Validate required fields
    if (!name || !organisation || !role || !email) {
      return NextResponse.json(
        { error: 'Required fields missing' },
        { status: 400 }
      )
    }

    const emailBody = `
NEW SCOPING ENQUIRY — STIEMFIELD

Name: ${name}
Organisation: ${organisation}
Role: ${role}
Email: ${email}
Country: ${country || 'Not provided'}
Organisation Size: ${size || 'Not provided'}
Service of Interest: ${service || 'Not provided'}
How They Found Stiemfield: ${source || 'Not provided'}

SITUATION:
${situation || 'Not provided'}

---
Submitted via stiemfield.com scoping form
    `.trim()

    // Send via Resend
    const RESEND_API_KEY = process.env.RESEND_API_KEY

    if (!RESEND_API_KEY) {
      // In development without Resend key, log to console
      console.log('Form submission received:', emailBody)
      return NextResponse.json({ success: true })
    }

    const res = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        from: 'Stiemfield Website <onboarding@resend.dev>',
        to: ['terungwa@stiemfield.com'],
        reply_to: email,
        subject: `New Scoping Enquiry — ${name}, ${organisation}`,
        text: emailBody,
      }),
    })

    if (!res.ok) {
      const error = await res.json()
      console.error('Resend error:', error)
      return NextResponse.json({ error: 'Email sending failed' }, { status: 500 })
    }

    return NextResponse.json({ success: true })
  } catch (err) {
    console.error('Contact API error:', err)
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 })
  }
}
