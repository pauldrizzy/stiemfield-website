import type { Metadata } from 'next'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import About from '@/components/sections/About'
import STIEMFramework from '@/components/sections/STIEMFramework'

export const metadata: Metadata = {
  title: 'About',
  description:
    'Stiemfield is a thesis firm — a professional services practice built on a single, defensible intellectual proposition: the STIEM Framework.',
}

export default function AboutPage() {
  return (
    <>
      <Navigation />
      <main>
        <div
          className="pt-36 pb-20 px-6 lg:px-12"
          style={{ background: 'var(--navy)' }}
        >
          <div className="max-w-7xl mx-auto">
            <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
              THE FIRM
            </p>
            <h1
              className="display-heading text-white max-w-2xl"
              style={{ fontSize: 'clamp(2.2rem, 4vw, 3.4rem)' }}
            >
              Structure is the substrate of integrity.
            </h1>
          </div>
        </div>
        <About />
        <STIEMFramework />
      </main>
      <Footer />
    </>
  )
}
