import type { Metadata } from 'next'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import Services from '@/components/sections/Services'

export const metadata: Metadata = {
  title: 'Services',
  description:
    'Fieldscan, Fieldforce, and Fieldpartner — three services, one logical progression from diagnosis through implementation to ongoing convergence advisory.',
}

export default function ServicesPage() {
  return (
    <>
      <Navigation />
      <main>
        <div
          className="pt-36 pb-20 px-6 lg:px-12"
          style={{ background: 'var(--navy)' }}
        >
          <div className="max-w-7xl mx-auto">
            <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
              SERVICE ARCHITECTURE
            </p>
            <h1
              className="display-heading text-white max-w-2xl"
              style={{ fontSize: 'clamp(2.2rem, 4vw, 3.4rem)' }}
            >
              Three services.
              <br />
              One progression.
            </h1>
          </div>
        </div>
        <Services />
      </main>
      <Footer />
    </>
  )
}
