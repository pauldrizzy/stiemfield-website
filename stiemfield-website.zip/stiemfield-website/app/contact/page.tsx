import type { Metadata } from 'next'
import Navigation from '@/components/layout/Navigation'
import Footer from '@/components/layout/Footer'
import ContactForm from '@/components/sections/ContactForm'

export const metadata: Metadata = {
  title: 'Contact',
  description:
    'Begin the scoping conversation with Stiemfield. Every engagement starts with a 30-minute scoping call.',
}

export default function ContactPage() {
  return (
    <>
      <Navigation />
      <main>
        <div
          className="pt-36 pb-20 px-6 lg:px-12"
          style={{ background: 'var(--navy)' }}
        >
          <div className="max-w-7xl mx-auto">
            <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
              SCOPING ENQUIRY
            </p>
            <h1
              className="display-heading text-white max-w-2xl"
              style={{ fontSize: 'clamp(2.2rem, 4vw, 3.4rem)' }}
            >
              Every engagement starts here.
            </h1>
          </div>
        </div>
        <ContactForm />
      </main>
      <Footer />
    </>
  )
}
