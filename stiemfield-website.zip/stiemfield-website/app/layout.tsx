import type { Metadata } from 'next'
import './globals.css'
import { Analytics } from '@vercel/analytics/react'

export const metadata: Metadata = {
  title: {
    default: 'Stiemfield | Global Convergence Consulting Firm',
    template: '%s | Stiemfield',
  },
  description:
    'Stiemfield applies the proprietary STIEM Framework to diagnose why organisational transformation fails and architect the convergence that makes it succeed. Rooted in Africa. Operating globally.',
  keywords: [
    'management consulting Africa',
    'organisational transformation Nigeria',
    'STIEM Framework',
    'convergence consulting',
    'Fieldscan',
    'Terungwa Paul Asar',
    'consulting firm Nigeria',
    'strategy execution gap',
  ],
  authors: [{ name: 'Terungwa Paul Asar' }],
  creator: 'Stiemfield Consulting Limited',
  openGraph: {
    type: 'website',
    locale: 'en_GB',
    url: 'https://stiemfield.com',
    siteName: 'Stiemfield',
    title: 'Stiemfield — Global Convergence Firm',
    description:
      'Transformation fails not because any one force is weak. It fails because five forces operate in isolation. Stiemfield diagnoses that isolation with evidence.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Stiemfield — Global Convergence Firm, Rooted in Africa',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Stiemfield — Global Convergence Firm',
    description:
      'Proprietary STIEM diagnostic. African contextual fluency. Global delivery.',
    images: ['/og-image.png'],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true },
  },
  metadataBase: new URL('https://stiemfield.com'),
}

const jsonLd = {
  '@context': 'https://schema.org',
  '@type': 'Organization',
  name: 'Stiemfield Consulting Limited',
  alternateName: 'Stiemfield',
  url: 'https://stiemfield.com',
  email: 'terungwa@stiemfield.com',
  description:
    'Global convergence consulting firm applying the STIEM Framework to diagnose and close organisational convergence gaps.',
  foundingDate: '2026',
  founder: {
    '@type': 'Person',
    name: 'Terungwa Paul Asar',
    jobTitle: 'Founding Partner',
  },
  areaServed: ['NG', 'KE', 'GH', 'ZA', 'RW', 'EG', 'CI', 'GB', 'US', 'AE'],
  serviceType: 'Management Consulting',
  slogan: 'Global Convergence Firm — Rooted in Africa',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en-GB" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />
      </head>
      <body>
        {children}
        <Analytics />
      </body>
    </html>
  )
}
