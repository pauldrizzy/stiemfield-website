import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

const previewArticles = [
  {
    slug: 'introducing-the-stiem-framework',
    title: 'Introducing the STIEM Framework',
    pillar: 'Methodology',
    pillarColor: 'var(--teal)',
    excerpt:
      'The five forces, the two scoring dimensions, and the gap patterns that explain why transformation programmes underdeliver despite capable components.',
    date: 'May 2026',
  },
  {
    slug: 'strategy-execution-gap-nigerian-mid-market',
    title: 'The Strategy–Execution Gap in Nigerian Mid-Market Organisations',
    pillar: 'Strategy',
    pillarColor: 'var(--teal)',
    excerpt:
      'The most prevalent convergence gap pattern in Nigeria: strategy is defined, execution is attempted, and the architectural gap between them is systematically ignored.',
    date: 'May 2026',
  },
  {
    slug: 'why-digital-transformations-fail',
    title: 'Why Digital Transformations Fail (Without the Management Layer)',
    pillar: 'Technology',
    pillarColor: 'var(--amber)',
    excerpt:
      'Technology investment does not produce transformation outcomes on its own. The management layer that integrates the technology into how work is done is where most programmes fail.',
    date: 'May 2026',
  },
]

export default function InsightsPreview() {
  return (
    <section className="py-28" style={{ background: 'white' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="flex items-end justify-between mb-16">
          <div>
            <p className="section-label mb-4">PUBLISHED THINKING</p>
            <h2
              className="display-heading"
              style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)', color: 'var(--navy)' }}
            >
              Demonstrations of the analytical
              <br />
              capability Stiemfield brings
              <br />
              to every engagement.
            </h2>
          </div>
          <Link
            href="/insights"
            className="hidden md:inline-flex items-center gap-2 text-sm font-medium transition-colors group"
            style={{ color: 'var(--teal)' }}
          >
            All Insights
            <ArrowRight
              size={14}
              className="transition-transform duration-200 group-hover:translate-x-1"
            />
          </Link>
        </div>

        {/* Article cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {previewArticles.map((article) => (
            <Link
              key={article.slug}
              href={`/insights/${article.slug}`}
              className="group flex flex-col border transition-all duration-200"
              style={{ borderColor: 'rgba(11,31,58,0.08)' }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = 'var(--teal)'
                el.style.transform = 'translateY(-2px)'
                el.style.boxShadow = '0 8px 32px rgba(13,115,119,0.1)'
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = 'rgba(11,31,58,0.08)'
                el.style.transform = 'translateY(0)'
                el.style.boxShadow = 'none'
              }}
            >
              {/* Pillar colour strip */}
              <div className="h-1" style={{ background: article.pillarColor }} />

              <div className="p-7 flex flex-col flex-1">
                <div className="flex items-center justify-between mb-4">
                  <span
                    className="text-xs tracking-widest px-2 py-1"
                    style={{
                      fontFamily: 'var(--font-dm-mono, monospace)',
                      color: article.pillarColor,
                      background: `${article.pillarColor}15`,
                    }}
                  >
                    {article.pillar.toUpperCase()}
                  </span>
                  <span className="text-xs" style={{ color: 'var(--slate)', opacity: 0.5 }}>
                    {article.date}
                  </span>
                </div>

                <h3
                  className="font-semibold mb-3 leading-snug flex-1"
                  style={{
                    fontFamily: 'var(--font-cormorant, serif)',
                    fontSize: '1.3rem',
                    color: 'var(--navy)',
                  }}
                >
                  {article.title}
                </h3>

                <p className="text-sm leading-relaxed mb-5" style={{ color: 'var(--slate)' }}>
                  {article.excerpt}
                </p>

                <div
                  className="inline-flex items-center gap-2 text-xs font-medium group-hover:gap-3 transition-all duration-200"
                  style={{ color: 'var(--teal)' }}
                >
                  Read Article
                  <ArrowRight size={12} />
                </div>
              </div>
            </Link>
          ))}
        </div>

        {/* Mobile view all */}
        <div className="mt-8 text-center md:hidden">
          <Link
            href="/insights"
            className="inline-flex items-center gap-2 text-sm font-medium"
            style={{ color: 'var(--teal)' }}
          >
            View all Insights <ArrowRight size={14} />
          </Link>
        </div>
      </div>
    </section>
  )
}
