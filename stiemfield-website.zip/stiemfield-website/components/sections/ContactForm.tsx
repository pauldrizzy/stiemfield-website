'use client'

import { useState } from 'react'
import { Send, CheckCircle2 } from 'lucide-react'

type FormState = 'idle' | 'submitting' | 'success' | 'error'

export default function ContactForm() {
  const [state, setState] = useState<FormState>('idle')
  const [form, setForm] = useState({
    name: '',
    organisation: '',
    role: '',
    email: '',
    country: '',
    size: '',
    service: '',
    situation: '',
    source: '',
  })

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }))
  }

  const handleSubmit = async (e: React.MouseEvent) => {
    e.preventDefault()
    setState('submitting')
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      })
      if (res.ok) {
        setState('success')
      } else {
        setState('error')
      }
    } catch {
      setState('error')
    }
  }

  const inputClass =
    'w-full px-4 py-3 text-sm border outline-none transition-all duration-200 bg-white'
  const inputStyle = {
    borderColor: 'rgba(11,31,58,0.15)',
    color: 'var(--navy)',
    fontFamily: 'var(--font-dm-sans, sans-serif)',
  }

  return (
    <section className="py-28" style={{ background: 'var(--canvas)' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          {/* Left — copy */}
          <div>
            <p className="section-label mb-6">BEGIN THE CONVERSATION</p>
            <h2
              className="display-heading mb-6"
              style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)', color: 'var(--navy)' }}
            >
              Begin the scoping conversation.
            </h2>
            <p className="text-base leading-relaxed mb-8" style={{ color: 'var(--slate)' }}>
              Every engagement starts with a 30-minute scoping call. No commitment
              required. The call establishes whether a Fieldscan is the right
              instrument for your organisation's situation — and if so, which tier.
            </p>

            {/* What to expect */}
            <div className="space-y-4 mb-10">
              {[
                {
                  time: '5 min',
                  label: 'Introduction and context',
                },
                {
                  time: '15 min',
                  label: 'You describe your organisation's situation',
                },
                {
                  time: '5 min',
                  label: 'We reflect what we hear and name the likely gap pattern',
                },
                {
                  time: '5 min',
                  label: 'Pathway discussion — Fieldscan tier indicated based on scope',
                },
              ].map((step) => (
                <div key={step.time} className="flex items-start gap-4">
                  <span
                    className="text-xs font-mono px-2 py-1 flex-shrink-0 mt-0.5"
                    style={{
                      background: 'var(--navy)',
                      color: 'var(--amber)',
                    }}
                  >
                    {step.time}
                  </span>
                  <span className="text-sm" style={{ color: 'var(--slate)' }}>
                    {step.label}
                  </span>
                </div>
              ))}
            </div>

            <div
              className="p-5 border-l-4"
              style={{ borderColor: 'var(--teal)', background: 'white' }}
            >
              <p className="text-xs font-mono tracking-widest mb-1" style={{ color: 'var(--teal)' }}>
                DIRECT CONTACT
              </p>
              <a
                href="mailto:terungwa@stiemfield.com"
                className="text-sm font-medium"
                style={{ color: 'var(--navy)' }}
              >
                terungwa@stiemfield.com
              </a>
              <p className="text-xs mt-1" style={{ color: 'var(--slate)', opacity: 0.6 }}>
                All enquiries treated with strict confidentiality.
                <br />
                Response within 2 business days.
              </p>
            </div>
          </div>

          {/* Right — form */}
          <div>
            {state === 'success' ? (
              <div
                className="flex flex-col items-center justify-center h-full text-center p-12"
                style={{ background: 'white', border: '1px solid rgba(11,31,58,0.08)' }}
              >
                <CheckCircle2 size={48} className="mb-4" style={{ color: 'var(--teal)' }} />
                <h3
                  className="display-heading mb-3"
                  style={{ fontSize: '1.8rem', color: 'var(--navy)' }}
                >
                  Enquiry received.
                </h3>
                <p className="text-sm" style={{ color: 'var(--slate)' }}>
                  Thank you. You will hear from us within 2 business days.
                </p>
              </div>
            ) : (
              <div
                className="p-8"
                style={{ background: 'white', border: '1px solid rgba(11,31,58,0.08)' }}
              >
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      FULL NAME *
                    </label>
                    <input
                      type="text"
                      name="name"
                      value={form.name}
                      onChange={handleChange}
                      required
                      className={inputClass}
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      ORGANISATION *
                    </label>
                    <input
                      type="text"
                      name="organisation"
                      value={form.organisation}
                      onChange={handleChange}
                      required
                      className={inputClass}
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      ROLE / TITLE *
                    </label>
                    <input
                      type="text"
                      name="role"
                      value={form.role}
                      onChange={handleChange}
                      required
                      className={inputClass}
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      EMAIL ADDRESS *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={form.email}
                      onChange={handleChange}
                      required
                      className={inputClass}
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      COUNTRY *
                    </label>
                    <input
                      type="text"
                      name="country"
                      value={form.country}
                      onChange={handleChange}
                      required
                      className={inputClass}
                      style={inputStyle}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                  </div>
                  <div>
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      ORGANISATION SIZE
                    </label>
                    <select
                      name="size"
                      value={form.size}
                      onChange={handleChange}
                      className={inputClass}
                      style={{ ...inputStyle, appearance: 'none' }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    >
                      <option value="">Select…</option>
                      <option>Under 50 staff</option>
                      <option>50–200 staff</option>
                      <option>200–500 staff</option>
                      <option>500+ staff</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      WHICH SERVICE INTERESTS YOU?
                    </label>
                    <select
                      name="service"
                      value={form.service}
                      onChange={handleChange}
                      className={inputClass}
                      style={{ ...inputStyle, appearance: 'none' }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    >
                      <option value="">Select…</option>
                      <option>Fieldscan — Convergence Diagnostic</option>
                      <option>Fieldforce — Convergence Implementation</option>
                      <option>Fieldpartner — Convergence Retainer</option>
                      <option>Not sure yet</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      BRIEFLY DESCRIBE YOUR SITUATION
                    </label>
                    <textarea
                      name="situation"
                      value={form.situation}
                      onChange={handleChange}
                      rows={4}
                      maxLength={500}
                      className={inputClass}
                      style={{ ...inputStyle, resize: 'vertical' }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    />
                    <p className="text-xs text-right mt-1" style={{ color: 'var(--slate)', opacity: 0.4 }}>
                      {form.situation.length}/500
                    </p>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-xs tracking-widest mb-1.5" style={{ color: 'var(--navy)', fontFamily: 'var(--font-dm-mono, monospace)' }}>
                      HOW DID YOU HEAR ABOUT STIEMFIELD?
                    </label>
                    <select
                      name="source"
                      value={form.source}
                      onChange={handleChange}
                      className={inputClass}
                      style={{ ...inputStyle, appearance: 'none' }}
                      onFocus={(e) => (e.target.style.borderColor = 'var(--teal)')}
                      onBlur={(e) => (e.target.style.borderColor = 'rgba(11,31,58,0.15)')}
                    >
                      <option value="">Select…</option>
                      <option>LinkedIn</option>
                      <option>Referral</option>
                      <option>Article / Insights</option>
                      <option>Direct search</option>
                      <option>Other</option>
                    </select>
                  </div>
                </div>

                <button
                  onClick={handleSubmit}
                  disabled={state === 'submitting'}
                  className="mt-6 w-full flex items-center justify-center gap-3 px-6 py-4 text-sm font-medium tracking-wide transition-all duration-200 disabled:opacity-60"
                  style={{ background: 'var(--teal)', color: 'white' }}
                  onMouseEnter={(e) => {
                    if (state !== 'submitting')
                      (e.currentTarget as HTMLElement).style.background = 'var(--teal-light)'
                  }}
                  onMouseLeave={(e) =>
                    ((e.currentTarget as HTMLElement).style.background = 'var(--teal)')
                  }
                >
                  <Send size={15} />
                  {state === 'submitting' ? 'Sending…' : 'Request Scoping Call'}
                </button>

                {state === 'error' && (
                  <p className="text-xs text-center mt-3" style={{ color: '#dc2626' }}>
                    Something went wrong. Please email us directly at terungwa@stiemfield.com
                  </p>
                )}

                <p className="text-xs text-center mt-4" style={{ color: 'var(--slate)', opacity: 0.5 }}>
                  Responses within 2 business days. All enquiries treated with strict confidentiality.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
