const tiers = [
  {
    label: 'PRIMARY',
    name: 'Nigeria',
    status: 'Year 1 onward · Home market',
    color: 'var(--teal)',
    description:
      'Virtual delivery nationwide. In-person available across primary LGAs: Abuja, Lagos, Port Harcourt, Kano, Ibadan, Makurdi, Kaduna, Enugu, Calabar, Onitsha.',
    markers: ['Federal Capital Territory', 'Lagos Commercial', 'Port Harcourt', 'Kano', 'Ibadan', 'Benue / Makurdi'],
  },
  {
    label: 'SECONDARY',
    name: 'Pan-African',
    status: 'Year 1 onward · Virtual-first',
    color: 'var(--amber)',
    description:
      'Virtual-first from Day One across priority markets. From Year 3, in-market associate partnerships activate for in-person Fieldforce presence.',
    markers: ['Kenya', 'Ghana', 'South Africa', 'Rwanda', 'Egypt', 'Côte d\'Ivoire'],
  },
  {
    label: 'TERTIARY',
    name: 'International',
    status: 'Year 1 onward · Targeted opportunistic',
    color: 'rgba(255,255,255,0.5)',
    description:
      'UK, US, UAE, EU — primarily diaspora-led organisations, multinationals with African operations, and Development Finance Institutions with African portfolios. USD or GBP billing.',
    markers: ['United Kingdom', 'United States', 'UAE', 'European Union'],
  },
]

export default function Geography() {
  return (
    <section className="py-28" style={{ background: 'var(--navy-light, #112952)' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="mb-16">
          <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
            GEOGRAPHIC ARCHITECTURE
          </p>
          <h2
            className="display-heading text-white max-w-2xl"
            style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)' }}
          >
            Global Convergence Firm.
            <br />
            Rooted in Africa.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-white/5">
          {tiers.map((tier, i) => (
            <div
              key={tier.name}
              className="p-8"
              style={{ background: 'rgba(11,31,58,0.5)' }}
            >
              <div className="flex items-start justify-between mb-6">
                <div>
                  <p
                    className="text-xs tracking-[0.2em] mb-1"
                    style={{
                      fontFamily: 'var(--font-dm-mono, monospace)',
                      color: tier.color,
                    }}
                  >
                    {tier.label}
                  </p>
                  <h3
                    className="text-white font-semibold"
                    style={{
                      fontFamily: 'var(--font-cormorant, serif)',
                      fontSize: '1.8rem',
                    }}
                  >
                    {tier.name}
                  </h3>
                  <p
                    className="text-xs mt-1"
                    style={{ color: 'rgba(255,255,255,0.4)' }}
                  >
                    {tier.status}
                  </p>
                </div>
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold"
                  style={{
                    background: `${i === 0 ? 'var(--teal)' : i === 1 ? 'rgba(244,169,0,0.2)' : 'rgba(255,255,255,0.1)'}`,
                    color: tier.color,
                    fontFamily: 'var(--font-cormorant, serif)',
                  }}
                >
                  {i + 1}
                </div>
              </div>

              <p className="text-sm leading-relaxed mb-6" style={{ color: 'rgba(255,255,255,0.6)' }}>
                {tier.description}
              </p>

              <div className="space-y-2">
                {tier.markers.map((m) => (
                  <div
                    key={m}
                    className="flex items-center gap-2 text-xs"
                    style={{ color: 'rgba(255,255,255,0.4)' }}
                  >
                    <span
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ background: tier.color }}
                    />
                    {m}
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {/* Public sector note */}
        <div
          className="mt-8 p-6 border-l-4"
          style={{
            borderColor: 'var(--amber)',
            background: 'rgba(244,169,0,0.06)',
          }}
        >
          <p
            className="text-xs tracking-widest mb-2"
            style={{ color: 'var(--amber)', fontFamily: 'var(--font-dm-mono, monospace)' }}
          >
            PUBLIC SECTOR STRATEGY
          </p>
          <p className="text-sm leading-relaxed" style={{ color: 'rgba(255,255,255,0.7)' }}>
            Public sector engagements are Nigerian only for at least the first decade — federal,
            state, and sub-national tiers. The firm builds deep Nigerian public sector capability
            before any Pan-African public sector consideration (Year 11+). Private sector
            engagement is global from Day One.
          </p>
        </div>
      </div>
    </section>
  )
}
