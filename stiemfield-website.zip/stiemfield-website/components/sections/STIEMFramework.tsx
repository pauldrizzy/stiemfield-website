'use client'

import { useState } from 'react'

const forces = [
  {
    key: 'S',
    label: 'Strategy',
    color: '#0D7377',
    definition:
      'The organisation\'s competitive direction, prioritisation logic, and decision-making coherence.',
    detail:
      'A strategy force weakness produces direction confusion — initiatives compete for resources, priorities shift without evidence, and decisions do not compound toward a coherent destination.',
    angle: 270, // top
  },
  {
    key: 'T',
    label: 'Technology',
    color: '#14919B',
    definition:
      'Digital infrastructure, systems maturity, and technology-strategy alignment.',
    detail:
      'Technology investment that does not align with strategy produces capability without direction. Systems are deployed; adoption is forced; the management layer to integrate them is absent.',
    angle: 342, // upper right
  },
  {
    key: 'I',
    label: 'Innovation',
    color: '#F4A900',
    definition:
      'Capacity to generate, test, and operationalise new value.',
    detail:
      'Innovation without execution architecture produces announcements, not outcomes. Ideas are piloted; pilots are celebrated; scale never arrives because the operational grounding was never built.',
    angle: 54, // lower right
  },
  {
    key: 'E',
    label: 'Execution',
    color: '#F4A900',
    definition:
      'Ability to translate decisions into consistent operational reality.',
    detail:
      'Execution failure is the most visible symptom and the most misdiagnosed root cause. Programmes stall not because execution is poor in isolation, but because the forces it must connect to are not aligned with it.',
    angle: 126, // lower left
  },
  {
    key: 'M',
    label: 'Management',
    color: '#0D7377',
    definition:
      'Leadership alignment, governance quality, organisational culture, and people systems.',
    detail:
      'Management collapse is the most structurally dangerous pattern — when leadership misalignment is severe enough, it undermines all other forces regardless of their individual strength.',
    angle: 198, // upper left
  },
]

const toRadians = (deg: number) => (deg * Math.PI) / 180
const cx = 200
const cy = 200
const r = 130
const nodeR = 28

function getPoint(angle: number, radius: number) {
  return {
    x: cx + radius * Math.cos(toRadians(angle - 90)),
    y: cy + radius * Math.sin(toRadians(angle - 90)),
  }
}

export default function STIEMFramework() {
  const [activeForce, setActiveForce] = useState<string | null>(null)
  const active = forces.find((f) => f.key === activeForce)

  const nodePoints = forces.map((f) => getPoint(f.angle, r))

  // All pairs for connecting lines
  const pairs: [number, number][] = []
  for (let i = 0; i < forces.length; i++) {
    for (let j = i + 1; j < forces.length; j++) {
      pairs.push([i, j])
    }
  }

  return (
    <section className="py-28" style={{ background: 'var(--canvas)' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="section-label mb-4">THE METHODOLOGY</p>
          <h2
            className="display-heading mb-6"
            style={{
              fontSize: 'clamp(2rem, 4vw, 3.2rem)',
              color: 'var(--navy)',
            }}
          >
            Five Forces. Two Dimensions.
            <br />
            One Convergence Map.
          </h2>
          <p
            className="text-base max-w-xl mx-auto leading-relaxed"
            style={{ color: 'var(--slate)' }}
          >
            Click any force below to explore its role in the convergence
            diagnostic.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row gap-16 items-center">
          {/* Pentagon SVG */}
          <div className="flex-shrink-0">
            <svg
              viewBox="0 0 400 400"
              width="400"
              height="400"
              className="max-w-full"
              style={{ maxWidth: '380px' }}
            >
              {/* Connection lines */}
              {pairs.map(([i, j]) => {
                const a = nodePoints[i]
                const b = nodePoints[j]
                const isActive =
                  activeForce === forces[i].key ||
                  activeForce === forces[j].key
                return (
                  <line
                    key={`${i}-${j}`}
                    x1={a.x}
                    y1={a.y}
                    x2={b.x}
                    y2={b.y}
                    stroke={isActive ? 'var(--teal)' : 'rgba(13,115,119,0.15)'}
                    strokeWidth={isActive ? 1.5 : 0.8}
                    style={{ transition: 'all 0.3s ease' }}
                  />
                )
              })}

              {/* Pentagon outline */}
              <polygon
                points={nodePoints.map((p) => `${p.x},${p.y}`).join(' ')}
                fill="rgba(13,115,119,0.04)"
                stroke="rgba(13,115,119,0.2)"
                strokeWidth="1"
              />

              {/* Centre label */}
              <text
                x={cx}
                y={cy - 8}
                textAnchor="middle"
                fill="var(--navy)"
                fontSize="11"
                fontFamily="var(--font-dm-mono, monospace)"
                letterSpacing="4"
                opacity="0.4"
              >
                CONVERGENCE
              </text>
              <circle cx={cx} cy={cy} r="3" fill="var(--teal)" opacity="0.5" />

              {/* Force nodes */}
              {forces.map((force, i) => {
                const p = nodePoints[i]
                const isActive = activeForce === force.key
                return (
                  <g
                    key={force.key}
                    style={{ cursor: 'pointer' }}
                    onClick={() =>
                      setActiveForce(isActive ? null : force.key)
                    }
                  >
                    {/* Glow ring on active */}
                    {isActive && (
                      <circle
                        cx={p.x}
                        cy={p.y}
                        r={nodeR + 8}
                        fill="none"
                        stroke="var(--teal)"
                        strokeWidth="1"
                        opacity="0.3"
                      />
                    )}
                    <circle
                      cx={p.x}
                      cy={p.y}
                      r={nodeR}
                      fill={isActive ? 'var(--navy)' : 'white'}
                      stroke={isActive ? 'var(--teal)' : 'var(--navy)'}
                      strokeWidth={isActive ? 2 : 1.5}
                      style={{ transition: 'all 0.25s ease' }}
                    />
                    <text
                      x={p.x}
                      y={p.y - 4}
                      textAnchor="middle"
                      dominantBaseline="middle"
                      fontSize="16"
                      fontWeight="600"
                      fontFamily="var(--font-cormorant, serif)"
                      fill={isActive ? 'var(--teal-light)' : 'var(--navy)'}
                      style={{ transition: 'fill 0.25s ease' }}
                    >
                      {force.key}
                    </text>
                    <text
                      x={p.x}
                      y={p.y + 11}
                      textAnchor="middle"
                      fontSize="7.5"
                      fontFamily="var(--font-dm-mono, monospace)"
                      letterSpacing="1.5"
                      fill={isActive ? 'rgba(255,255,255,0.6)' : 'rgba(11,31,58,0.4)'}
                      style={{ transition: 'fill 0.25s ease' }}
                    >
                      {force.label.toUpperCase()}
                    </text>
                  </g>
                )
              })}
            </svg>
          </div>

          {/* Info panel */}
          <div className="flex-1 min-w-0">
            {active ? (
              <div
                className="p-8 border-l-4"
                style={{
                  borderColor: 'var(--teal)',
                  background: 'white',
                  transition: 'all 0.3s ease',
                }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <span className="section-label" style={{ color: 'var(--amber)' }}>
                      FORCE {active.key}
                    </span>
                    <h3
                      className="display-heading mt-1"
                      style={{ fontSize: '2.2rem', color: 'var(--navy)' }}
                    >
                      {active.label}
                    </h3>
                  </div>
                  <span
                    className="text-4xl font-bold"
                    style={{
                      fontFamily: 'var(--font-cormorant, serif)',
                      color: 'var(--teal)',
                      opacity: 0.3,
                    }}
                  >
                    {active.key}
                  </span>
                </div>
                <p
                  className="text-base font-medium mb-4 leading-relaxed"
                  style={{ color: 'var(--navy)' }}
                >
                  {active.definition}
                </p>
                <p className="text-sm leading-relaxed" style={{ color: 'var(--slate)' }}>
                  {active.detail}
                </p>
              </div>
            ) : (
              <div className="p-8" style={{ background: 'white' }}>
                <p className="section-label mb-6" style={{ color: 'var(--amber)' }}>
                  TWO SCORING DIMENSIONS
                </p>
                <div className="space-y-6">
                  <div
                    className="p-6 border-l-2"
                    style={{ borderColor: 'var(--teal)', background: 'var(--canvas)' }}
                  >
                    <div className="flex items-baseline gap-3 mb-2">
                      <span
                        className="text-3xl font-bold"
                        style={{
                          fontFamily: 'var(--font-cormorant, serif)',
                          color: 'var(--teal)',
                        }}
                      >
                        1–5
                      </span>
                      <h4
                        className="font-semibold text-sm tracking-wide"
                        style={{ color: 'var(--navy)' }}
                      >
                        ABSOLUTE STRENGTH
                      </h4>
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: 'var(--slate)' }}>
                      How strong is this force on its own terms? Independent of
                      how it connects to other forces.
                    </p>
                  </div>
                  <div
                    className="p-6 border-l-2"
                    style={{ borderColor: 'var(--amber)', background: 'var(--canvas)' }}
                  >
                    <div className="flex items-baseline gap-3 mb-2">
                      <span
                        className="text-3xl font-bold"
                        style={{
                          fontFamily: 'var(--font-cormorant, serif)',
                          color: 'var(--amber)',
                        }}
                      >
                        1–5
                      </span>
                      <h4
                        className="font-semibold text-sm tracking-wide"
                        style={{ color: 'var(--navy)' }}
                      >
                        CONVERGENCE QUALITY
                      </h4>
                    </div>
                    <p className="text-sm leading-relaxed" style={{ color: 'var(--slate)' }}>
                      How well does this force connect to all four others in
                      real time? A force may be internally strong yet poorly
                      connected.
                    </p>
                  </div>
                </div>
              </div>
            )}

            <p
              className="text-xs mt-4 text-center"
              style={{ color: 'var(--slate)', opacity: 0.5 }}
            >
              Select a force node to explore
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
