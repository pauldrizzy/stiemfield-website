import Link from 'next/link'
import { ArrowRight, CheckCircle2 } from 'lucide-react'

const services = [
  {
    id: 'fieldscan',
    label: 'ENTRY ENGAGEMENT',
    name: 'Fieldscan',
    subtitle: 'The Convergence Diagnostic',
    description:
      'A structured, evidence-based engagement that scores each STIEM force on two dimensions, identifies the gap pattern producing your transformation failure, and prescribes the prioritised intervention architecture.',
    deliverable: 'The Convergence Map (~40–60 pages)',
    tiers: [
      { name: 'Standard', fee: '₦1,500,000', weeks: '4 weeks', scope: 'Under 100 staff' },
      { name: 'Extended', fee: '₦1,750,000', weeks: '6 weeks', scope: '100–500 staff' },
      {
        name: 'Comprehensive',
        fee: '₦2,000,000',
        weeks: '8 weeks',
        scope: '500+ staff or multi-unit',
      },
    ],
    paymentNote: '50% on engagement signing · 50% on Convergence Map delivery',
    highlights: [
      '6–8 stakeholder interviews across 3+ organisational levels',
      'Document review across 3+ STIEM force categories',
      'Evidence-backed scoring — minimum two independent sources per finding',
      '90–120 minute leadership presentation',
      'Named Client Anchor throughout',
    ],
    cta: 'Begin Scoping',
    href: '/contact',
    featured: true,
  },
  {
    id: 'fieldforce',
    label: 'YEAR 2 LAUNCH',
    name: 'Fieldforce',
    subtitle: 'The Convergence Implementation',
    description:
      'The multi-month implementation engagement that closes the convergence gaps identified in your Convergence Map. Monthly retainer combined with milestone payments tied to project outcomes.',
    note: 'Prerequisite: completed Stiemfield Fieldscan within the prior 12 months. No exceptions.',
    feeNote: 'Monthly retainer + milestone payments as % of project budget',
    durationNote: '3–12 months, milestone-based',
    highlights: [
      'Implementation of gap-closure interventions from the Convergence Map',
      'Monthly progress reports with evidence-tracked milestones',
      'Final STIEM re-scoring at engagement close',
      'Fieldforce Summary Report',
      'Client Anchor continuity from Fieldscan',
    ],
    cta: 'Learn More',
    href: '/services/fieldforce',
    featured: false,
  },
  {
    id: 'fieldpartner',
    label: 'YEAR 2 LAUNCH · ONGOING RETAINER',
    name: 'Fieldpartner',
    subtitle: 'The Convergence Retainer',
    description:
      'Ongoing embedded advisory that sustains convergence quality through subsequent strategic transitions. Minimum 6-month commitment reviewed every 6 months.',
    note: 'Strongly preferred: completed prior Fieldscan within the past 24 months.',
    feeNote: 'Monthly retainer billed in advance — from ₦1.5M/month (Year 2)',
    durationNote: 'Minimum 6-month commitment',
    highlights: [
      'Monthly leadership advisory sessions of 2–4 hours',
      'Asynchronous access for strategic decisions',
      'Quarterly STIEM re-scoring',
      'Annual Convergence Map refresh',
      'Client Anchor continuity across the engagement progression',
    ],
    cta: 'Learn More',
    href: '/services/fieldpartner',
    featured: false,
  },
]

export default function Services() {
  return (
    <section className="py-28" style={{ background: 'white' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        {/* Header */}
        <div className="mb-16">
          <p className="section-label mb-4">THREE SERVICES. ONE PROGRESSION.</p>
          <h2
            className="display-heading mb-4"
            style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)', color: 'var(--navy)' }}
          >
            Fieldscan diagnoses.
            <br />
            Fieldforce implements.
            <br />
            Fieldpartner sustains.
          </h2>
          <p className="text-sm max-w-xl leading-relaxed" style={{ color: 'var(--slate)' }}>
            Every Stiemfield engagement has a named Client Anchor — a permanent reserved seat
            providing institutional continuity across all three services.
          </p>
        </div>

        {/* Service cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {services.map((svc) => (
            <div
              key={svc.id}
              className="flex flex-col"
              style={{
                border: svc.featured
                  ? '2px solid var(--teal)'
                  : '1px solid rgba(11,31,58,0.1)',
                background: svc.featured ? 'var(--canvas)' : 'white',
              }}
            >
              {svc.featured && (
                <div
                  className="px-6 py-2 text-xs font-mono tracking-widest"
                  style={{ background: 'var(--teal)', color: 'white' }}
                >
                  PRIMARY SERVICE
                </div>
              )}

              <div className="p-8 flex flex-col flex-1">
                {/* Label */}
                <p className="section-label mb-3" style={{ color: 'var(--amber)' }}>
                  {svc.label}
                </p>

                {/* Name */}
                <h3
                  className="display-heading mb-1"
                  style={{ fontSize: '2rem', color: 'var(--navy)' }}
                >
                  {svc.name}
                </h3>
                <p className="text-sm font-medium mb-4" style={{ color: 'var(--teal)' }}>
                  {svc.subtitle}
                </p>

                {/* Description */}
                <p className="text-sm leading-relaxed mb-6" style={{ color: 'var(--slate)' }}>
                  {svc.description}
                </p>

                {/* Tier pricing (Fieldscan only) */}
                {'tiers' in svc && (
                  <div className="mb-6">
                    <div className="space-y-2">
                      {svc.tiers.map((tier) => (
                        <div
                          key={tier.name}
                          className="flex items-center justify-between p-3 text-sm"
                          style={{
                            background: 'white',
                            border: '1px solid rgba(11,31,58,0.08)',
                          }}
                        >
                          <div>
                            <span className="font-medium" style={{ color: 'var(--navy)' }}>
                              {tier.name}
                            </span>
                            <span
                              className="ml-2 text-xs"
                              style={{ color: 'var(--slate)', opacity: 0.7 }}
                            >
                              {tier.weeks} · {tier.scope}
                            </span>
                          </div>
                          <span
                            className="font-semibold"
                            style={{
                              fontFamily: 'var(--font-dm-mono, monospace)',
                              color: 'var(--teal)',
                              fontSize: '0.82rem',
                            }}
                          >
                            {tier.fee}
                          </span>
                        </div>
                      ))}
                    </div>
                    <p
                      className="text-xs mt-3 text-center"
                      style={{ color: 'var(--slate)', opacity: 0.7 }}
                    >
                      {svc.paymentNote}
                    </p>
                  </div>
                )}

                {/* Fee note (non-Fieldscan) */}
                {'feeNote' in svc && (
                  <div
                    className="mb-6 p-4"
                    style={{ background: 'var(--canvas)', border: '1px solid rgba(11,31,58,0.08)' }}
                  >
                    <p className="text-xs font-mono tracking-wide mb-1" style={{ color: 'var(--amber)' }}>
                      FEE STRUCTURE
                    </p>
                    <p className="text-sm" style={{ color: 'var(--navy)' }}>
                      {svc.feeNote}
                    </p>
                    <p className="text-xs mt-1" style={{ color: 'var(--slate)', opacity: 0.7 }}>
                      {svc.durationNote}
                    </p>
                  </div>
                )}

                {/* Highlights */}
                <ul className="space-y-2 mb-6 flex-1">
                  {svc.highlights.map((h) => (
                    <li key={h} className="flex items-start gap-3 text-sm">
                      <CheckCircle2
                        size={14}
                        className="flex-shrink-0 mt-0.5"
                        style={{ color: 'var(--teal)' }}
                      />
                      <span style={{ color: 'var(--slate)' }}>{h}</span>
                    </li>
                  ))}
                </ul>

                {/* Prerequisite note */}
                {'note' in svc && (
                  <p
                    className="text-xs leading-relaxed mb-6 p-3 border-l-2"
                    style={{
                      borderColor: 'var(--amber)',
                      background: 'rgba(244,169,0,0.05)',
                      color: 'var(--slate)',
                    }}
                  >
                    {svc.note}
                  </p>
                )}

                {/* CTA */}
                <Link
                  href={svc.href}
                  className="group inline-flex items-center justify-center gap-2 px-6 py-3 text-sm font-medium tracking-wide transition-all duration-200"
                  style={{
                    background: svc.featured ? 'var(--teal)' : 'transparent',
                    color: svc.featured ? 'white' : 'var(--teal)',
                    border: svc.featured ? 'none' : '1px solid var(--teal)',
                  }}
                  onMouseEnter={(e) => {
                    const el = e.currentTarget as HTMLElement
                    if (svc.featured) {
                      el.style.background = 'var(--teal-light)'
                    } else {
                      el.style.background = 'var(--teal)'
                      el.style.color = 'white'
                    }
                  }}
                  onMouseLeave={(e) => {
                    const el = e.currentTarget as HTMLElement
                    if (svc.featured) {
                      el.style.background = 'var(--teal)'
                    } else {
                      el.style.background = 'transparent'
                      el.style.color = 'var(--teal)'
                    }
                  }}
                >
                  {svc.cta}
                  <ArrowRight
                    size={14}
                    className="transition-transform duration-200 group-hover:translate-x-1"
                  />
                </Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
