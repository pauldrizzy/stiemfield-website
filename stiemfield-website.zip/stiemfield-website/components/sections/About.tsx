import { Linkedin } from 'lucide-react'

const stats = [
  { value: '500,000+', label: 'Nigerians trained under NITDA DL4ALL' },
  { value: '5 Forces', label: 'Examined in every engagement' },
  { value: '2 Dimensions', label: 'Absolute Strength + Convergence Quality' },
]

export default function About() {
  return (
    <section className="py-28" style={{ background: 'var(--canvas)' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Text column */}
          <div>
            <p className="section-label mb-6">THE FIRM</p>
            <h2
              className="display-heading mb-8"
              style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)', color: 'var(--navy)' }}
            >
              A thesis firm built on field evidence.
            </h2>

            <div className="space-y-5 mb-12">
              <p className="text-base leading-relaxed" style={{ color: 'var(--slate)' }}>
                Stiemfield emerged from two consecutive transformation engagements
                during the founding partner's National Youth Service Corps year in Osun
                State — serving as Project Manager and subsequently State Project Manager
                for NITDA's Digital Literacy for All programme.
              </p>
              <p className="text-base leading-relaxed" style={{ color: 'var(--slate)' }}>
                Three observations from the field produced the STIEM Framework. The
                strongest single force in any transformation cannot compensate for the
                absence of convergence with the others. This pattern holds across public,
                private, and development sectors. No diagnostic methodology, applied
                consistently in the African organisational context, was built to
                address it.
              </p>
              <blockquote
                className="border-l-4 pl-6 py-1"
                style={{ borderColor: 'var(--amber)' }}
              >
                <p
                  className="display-heading italic"
                  style={{ fontSize: '1.25rem', color: 'var(--navy)', lineHeight: 1.4 }}
                >
                  "Stiemfield is the response to the third observation."
                </p>
              </blockquote>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 mb-12">
              {stats.map((s) => (
                <div key={s.value}>
                  <div
                    className="font-bold mb-1"
                    style={{
                      fontFamily: 'var(--font-cormorant, serif)',
                      fontSize: '1.6rem',
                      color: 'var(--teal)',
                    }}
                  >
                    {s.value}
                  </div>
                  <div
                    className="text-xs leading-snug"
                    style={{ color: 'var(--slate)', opacity: 0.8 }}
                  >
                    {s.label}
                  </div>
                </div>
              ))}
            </div>

            {/* Founding partner */}
            <div
              className="flex items-center gap-4 p-5"
              style={{ background: 'white', border: '1px solid rgba(11,31,58,0.08)' }}
            >
              {/* Avatar placeholder */}
              <div
                className="w-14 h-14 rounded-full flex items-center justify-center flex-shrink-0"
                style={{ background: 'var(--navy)' }}
              >
                <span
                  className="text-white font-medium"
                  style={{
                    fontFamily: 'var(--font-cormorant, serif)',
                    fontSize: '1.2rem',
                  }}
                >
                  TP
                </span>
              </div>
              <div className="flex-1">
                <p className="font-semibold text-sm" style={{ color: 'var(--navy)' }}>
                  Terungwa Paul Asar
                </p>
                <p
                  className="text-xs mt-0.5"
                  style={{ color: 'var(--teal)', fontFamily: 'var(--font-dm-mono, monospace)', letterSpacing: '0.05em' }}
                >
                  Founding Partner
                </p>
                <p className="text-xs mt-0.5" style={{ color: 'var(--slate)', opacity: 0.7 }}>
                  BSc Business Management
                </p>
              </div>
              <a
                href="https://linkedin.com/in/terungwa-asar"
                target="_blank"
                rel="noopener noreferrer"
                className="p-2 transition-colors"
                style={{ color: 'var(--teal)' }}
                onMouseEnter={(e) =>
                  ((e.currentTarget as HTMLElement).style.color = 'var(--navy)')
                }
                onMouseLeave={(e) =>
                  ((e.currentTarget as HTMLElement).style.color = 'var(--teal)')
                }
              >
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          {/* Visual column */}
          <div className="relative">
            {/* Photo placeholder */}
            <div
              className="aspect-[4/5] w-full max-w-md mx-auto flex flex-col items-center justify-center relative overflow-hidden"
              style={{ background: 'var(--navy)' }}
            >
              {/* Grid overlay */}
              <svg
                className="absolute inset-0 w-full h-full opacity-10"
                xmlns="http://www.w3.org/2000/svg"
              >
                <defs>
                  <pattern id="photo-grid" width="40" height="40" patternUnits="userSpaceOnUse">
                    <path
                      d="M 40 0 L 0 0 0 40"
                      fill="none"
                      stroke="rgba(13,115,119,1)"
                      strokeWidth="0.5"
                    />
                  </pattern>
                </defs>
                <rect width="100%" height="100%" fill="url(#photo-grid)" />
              </svg>

              <div className="relative z-10 text-center p-8">
                <p
                  className="text-white/30 text-xs tracking-[0.3em] mb-8"
                  style={{ fontFamily: 'var(--font-dm-mono, monospace)' }}
                >
                  FOUNDING PARTNER PHOTO
                </p>
                <div
                  className="text-white/10 font-bold"
                  style={{
                    fontFamily: 'var(--font-cormorant, serif)',
                    fontSize: '5rem',
                    lineHeight: 1,
                  }}
                >
                  TPA
                </div>
                <p className="text-white/20 text-xs mt-6 tracking-widest">
                  REPLACE WITH PROFESSIONAL PHOTOGRAPHY
                </p>
              </div>

              {/* Bottom amber accent */}
              <div
                className="absolute bottom-0 left-0 right-0 h-1"
                style={{ background: 'var(--amber)' }}
              />
            </div>

            {/* Floating credential card */}
            <div
              className="absolute -bottom-6 -right-4 p-4 shadow-xl"
              style={{
                background: 'white',
                border: '1px solid rgba(11,31,58,0.08)',
                maxWidth: '200px',
              }}
            >
              <p
                className="text-xs tracking-widest mb-2"
                style={{ color: 'var(--amber)', fontFamily: 'var(--font-dm-mono, monospace)' }}
              >
                FIELD EXPERIENCE
              </p>
              <p className="text-xs leading-relaxed" style={{ color: 'var(--navy)' }}>
                NITDA DL4ALL Programme
                <br />
                <span style={{ color: 'var(--teal)' }}>State Project Manager</span>
                <br />
                Osun State, 2025–2026
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
