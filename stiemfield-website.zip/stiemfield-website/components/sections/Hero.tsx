'use client'

import { useEffect, useState } from 'react'
import Link from 'next/link'
import { ArrowRight, ChevronDown } from 'lucide-react'

const forces = ['STRATEGY', 'TECHNOLOGY', 'INNOVATION', 'EXECUTION', 'MANAGEMENT']

export default function Hero() {
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  return (
    <section
      className="relative min-h-screen flex flex-col justify-center overflow-hidden"
      style={{ background: 'var(--navy)' }}
    >
      {/* Animated mesh background */}
      <div className="absolute inset-0 pointer-events-none">
        <svg
          className="absolute inset-0 w-full h-full opacity-[0.06]"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <pattern id="grid" width="60" height="60" patternUnits="userSpaceOnUse">
              <path
                d="M 60 0 L 0 0 0 60"
                fill="none"
                stroke="rgba(13,115,119,0.8)"
                strokeWidth="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
        </svg>
        {/* Glow orbs */}
        <div
          className="absolute top-1/4 right-1/4 w-96 h-96 rounded-full opacity-10 blur-3xl"
          style={{ background: 'var(--teal)' }}
        />
        <div
          className="absolute bottom-1/4 left-1/6 w-64 h-64 rounded-full opacity-8 blur-3xl"
          style={{ background: 'var(--amber)' }}
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-6 lg:px-12 pt-32 pb-24">
        <div className="max-w-4xl">
          {/* Section label */}
          <p
            className={`section-label mb-8 transition-all duration-700 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
            }`}
            style={{ color: 'var(--amber)', transitionDelay: '100ms' }}
          >
            Global Convergence Firm — Rooted in Africa
          </p>

          {/* Main headline */}
          <h1
            className={`display-heading text-white mb-8 transition-all duration-700 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{
              fontSize: 'clamp(2.4rem, 5vw, 4.2rem)',
              lineHeight: '1.08',
              transitionDelay: '200ms',
            }}
          >
            Transformation fails not because
            <br />
            any one force is weak.
            <br />
            <em className="not-italic" style={{ color: 'rgba(255,255,255,0.5)' }}>
              It fails because five forces
            </em>
            <br />
            <em className="not-italic" style={{ color: 'rgba(255,255,255,0.5)' }}>
              operate in isolation.
            </em>
          </h1>

          {/* Subheadline */}
          <p
            className={`text-lg md:text-xl leading-relaxed mb-12 max-w-2xl transition-all duration-700 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{
              color: 'var(--teal-light)',
              transitionDelay: '350ms',
            }}
          >
            Stiemfield diagnoses that isolation with evidence — and architects
            the convergence that closes it.
          </p>

          {/* CTAs */}
          <div
            className={`flex flex-col sm:flex-row gap-4 mb-20 transition-all duration-700 ${
              mounted ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6'
            }`}
            style={{ transitionDelay: '500ms' }}
          >
            <Link
              href="/services/fieldscan"
              className="group inline-flex items-center gap-3 px-8 py-4 font-medium tracking-wide text-sm transition-all duration-200"
              style={{ background: 'var(--teal)', color: 'white' }}
              onMouseEnter={(e) =>
                ((e.currentTarget as HTMLElement).style.background = 'var(--teal-light)')
              }
              onMouseLeave={(e) =>
                ((e.currentTarget as HTMLElement).style.background = 'var(--teal)')
              }
            >
              Explore the Fieldscan
              <ArrowRight
                size={16}
                className="transition-transform duration-200 group-hover:translate-x-1"
              />
            </Link>
            <Link
              href="/insights"
              className="inline-flex items-center gap-3 px-8 py-4 font-medium tracking-wide text-sm border transition-all duration-200 text-white"
              style={{ borderColor: 'rgba(255,255,255,0.25)' }}
              onMouseEnter={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = 'rgba(255,255,255,0.6)'
                el.style.background = 'rgba(255,255,255,0.05)'
              }}
              onMouseLeave={(e) => {
                const el = e.currentTarget as HTMLElement
                el.style.borderColor = 'rgba(255,255,255,0.25)'
                el.style.background = 'transparent'
              }}
            >
              Read Our Thinking
            </Link>
          </div>

          {/* Five forces ticker */}
          <div
            className={`transition-all duration-700 ${
              mounted ? 'opacity-100' : 'opacity-0'
            }`}
            style={{ transitionDelay: '650ms' }}
          >
            <div className="flex flex-wrap gap-x-6 gap-y-2 items-center">
              {forces.map((force, i) => (
                <span key={force} className="flex items-center gap-6">
                  <span
                    className="text-xs tracking-[0.2em]"
                    style={{
                      fontFamily: 'var(--font-dm-mono, monospace)',
                      color: 'var(--amber)',
                    }}
                  >
                    {force}
                  </span>
                  {i < forces.length - 1 && (
                    <span className="w-1 h-1 rounded-full opacity-30 bg-white hidden sm:block" />
                  )}
                </span>
              ))}
            </div>
            <div
              className="mt-4 h-px w-48"
              style={{
                background:
                  'linear-gradient(90deg, var(--amber) 0%, transparent 100%)',
              }}
            />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 opacity-40 animate-bounce">
        <ChevronDown size={18} className="text-white" />
      </div>
    </section>
  )
}
