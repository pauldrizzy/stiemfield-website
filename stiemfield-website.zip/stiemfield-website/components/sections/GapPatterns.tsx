'use client'

import { useState } from 'react'

const gaps = [
  {
    id: 1,
    name: 'Strategy–Execution Gap',
    forces: 'S ↔ E',
    short:
      'Strategy is defined but execution architecture is absent or inadequate.',
    detail:
      'The most prevalent pattern in Nigerian private-sector organisations. Priorities are clear at the top; the organisation does not move. Not because people are incapable, but because the architecture connecting intent to action was never built.',
    accent: '#0D7377',
  },
  {
    id: 2,
    name: 'Technology–Management Gap',
    forces: 'T ↔ M',
    short:
      'Technology is deployed but management systems have not been updated to integrate it.',
    detail:
      'Common in post-digital-transformation environments. The platform is live, the training has happened, and the adoption numbers are poor — because the management layer governing how work is done was not redesigned alongside the technology.',
    accent: '#14919B',
  },
  {
    id: 3,
    name: 'Innovation–Execution Gap',
    forces: 'I ↔ E',
    short: 'Innovation is ideated and piloted but never operationalised at scale.',
    detail:
      'Common in growth-stage organisations. Innovation produces activity — workshops, pilots, announcements. It does not produce outcomes because the execution architecture required to convert an idea into an operational reality was never built.',
    accent: '#F4A900',
  },
  {
    id: 4,
    name: 'Strategy–Technology Misalignment',
    forces: 'S ↔ T',
    short: 'Technology investment does not match the stated strategic direction.',
    detail:
      'Technology spend is visible and auditable; strategic direction is often assumed rather than stated. The misalignment accumulates over time, producing a technology landscape that reflects the decisions of the past rather than the direction of the future.',
    accent: '#F7BC3D',
  },
  {
    id: 5,
    name: 'Management Collapse',
    forces: 'M undermines all',
    short:
      'Leadership misalignment is so severe it undermines all other forces regardless of their individual strength.',
    detail:
      'The most structurally dangerous pattern. Strategy is written. Technology is deployed. Execution is attempted. But the misalignment at leadership level — in direction, in commitment, in culture — consistently undermines what every other force is trying to achieve.',
    accent: '#0B1F3A',
  },
  {
    id: 6,
    name: 'Full Convergence Collapse',
    forces: 'All five disconnected',
    short:
      'All five forces are individually present but none are connected to each other.',
    detail:
      'The most complex and most recoverable pattern, because it is structural rather than personnel-driven. Five capable forces, each operating well within its own domain, each invisible to the others. The Convergence Map is the first instrument that makes this structural isolation visible.',
    accent: '#0B1F3A',
  },
]

export default function GapPatterns() {
  const [expanded, setExpanded] = useState<number | null>(null)

  return (
    <section className="py-28" style={{ background: 'var(--navy)' }}>
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="mb-16">
          <p className="section-label mb-4" style={{ color: 'var(--amber)' }}>
            THE SIX CONVERGENCE GAP PATTERNS
          </p>
          <h2
            className="display-heading text-white max-w-2xl"
            style={{ fontSize: 'clamp(1.9rem, 3.5vw, 3rem)' }}
          >
            Every transformation failure maps to one of these six structural patterns.
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-white/5">
          {gaps.map((gap) => (
            <div
              key={gap.id}
              className="p-8 cursor-pointer transition-all duration-250 group"
              style={{
                background:
                  expanded === gap.id ? 'rgba(13,115,119,0.12)' : 'rgba(11,31,58,0.6)',
              }}
              onClick={() => setExpanded(expanded === gap.id ? null : gap.id)}
              onMouseEnter={(e) => {
                if (expanded !== gap.id)
                  (e.currentTarget as HTMLElement).style.background =
                    'rgba(13,115,119,0.06)'
              }}
              onMouseLeave={(e) => {
                if (expanded !== gap.id)
                  (e.currentTarget as HTMLElement).style.background =
                    'rgba(11,31,58,0.6)'
              }}
            >
              {/* Forces tag */}
              <div
                className="inline-block px-2 py-1 text-xs font-mono tracking-widest mb-4"
                style={{
                  background: `${gap.accent}22`,
                  color: gap.accent === '#0B1F3A' ? 'var(--teal-light)' : gap.accent,
                  border: `1px solid ${gap.accent}33`,
                }}
              >
                {gap.forces}
              </div>

              <h3
                className="font-semibold mb-3 leading-snug"
                style={{
                  fontFamily: 'var(--font-cormorant, serif)',
                  fontSize: '1.4rem',
                  color: 'white',
                }}
              >
                {gap.name}
              </h3>

              <p className="text-sm leading-relaxed mb-4" style={{ color: 'rgba(255,255,255,0.55)' }}>
                {gap.short}
              </p>

              {expanded === gap.id && (
                <p
                  className="text-sm leading-relaxed pt-4 border-t"
                  style={{
                    color: 'rgba(255,255,255,0.7)',
                    borderColor: `${gap.accent}44`,
                  }}
                >
                  {gap.detail}
                </p>
              )}

              <div
                className="mt-4 text-xs tracking-wider transition-colors"
                style={{ color: expanded === gap.id ? 'var(--teal-light)' : 'rgba(255,255,255,0.25)' }}
              >
                {expanded === gap.id ? '↑ Collapse' : '↓ Read more'}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
