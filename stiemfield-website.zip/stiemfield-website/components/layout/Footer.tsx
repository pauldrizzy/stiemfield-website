import Link from 'next/link'
import { Linkedin, Mail, Globe } from 'lucide-react'

export default function Footer() {
  return (
    <footer style={{ background: 'var(--navy)' }} className="pt-20 pb-8">
      <div className="max-w-7xl mx-auto px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 pb-16 border-b border-white/10">
          {/* Column 1 — Brand */}
          <div>
            <div className="mb-4">
              <span
                className="text-white font-medium tracking-[0.3em] text-sm block mb-1"
                style={{ fontFamily: 'var(--font-dm-mono, monospace)' }}
              >
                S T I E M F I E L D
              </span>
              <span className="text-sm" style={{ color: 'var(--teal-light)', letterSpacing: '0.08em' }}>
                Global Convergence Firm — Rooted in Africa
              </span>
            </div>
            <p className="text-white/50 text-sm leading-relaxed mt-4">
              Stiemfield Consulting Limited
              <br />
              Incorporated in Nigeria under CAMA 2020
              <br />
              Year 1 Operating Base: Makurdi, Benue State
            </p>
            <p className="text-white/30 text-xs mt-4 tracking-wide">
              S · T · I · E · M
            </p>
          </div>

          {/* Column 2 — Navigation */}
          <div>
            <p
              className="section-label mb-6"
              style={{ color: 'var(--amber)' }}
            >
              Navigate
            </p>
            <div className="flex flex-col gap-3">
              {[
                { label: 'About', href: '/about' },
                { label: 'Services', href: '/services' },
                { label: 'Fieldscan', href: '/services/fieldscan' },
                { label: 'Insights', href: '/insights' },
                { label: 'Contact', href: '/contact' },
              ].map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  className="text-white/60 hover:text-white transition-colors text-sm"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          {/* Column 3 — Contact */}
          <div>
            <p className="section-label mb-6" style={{ color: 'var(--amber)' }}>
              Contact
            </p>
            <div className="flex flex-col gap-4">
              <a
                href="mailto:terungwa@stiemfield.com"
                className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm"
              >
                <Mail size={16} style={{ color: 'var(--teal-light)' }} />
                terungwa@stiemfield.com
              </a>
              <a
                href="https://stiemfield.com"
                className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm"
              >
                <Globe size={16} style={{ color: 'var(--teal-light)' }} />
                stiemfield.com
              </a>
              <a
                href="https://linkedin.com/in/terungwa-asar"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-3 text-white/60 hover:text-white transition-colors text-sm"
              >
                <Linkedin size={16} style={{ color: 'var(--teal-light)' }} />
                Terungwa Paul Asar
              </a>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <p className="text-white/30 text-xs">
            © 2026 Stiemfield Consulting Limited. All rights reserved.
          </p>
          <p className="text-white/20 text-xs max-w-md text-right leading-relaxed">
            STIEM Framework, Convergence Map, Fieldscan, Fieldforce, and Fieldpartner
            are proprietary marks of Stiemfield Consulting Limited.
          </p>
        </div>
      </div>
    </footer>
  )
}
