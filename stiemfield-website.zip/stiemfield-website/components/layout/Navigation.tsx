'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'

const navLinks = [
  { label: 'About', href: '/about' },
  { label: 'Services', href: '/services' },
  { label: 'Insights', href: '/insights' },
  { label: 'Contact', href: '/contact' },
]

export default function Navigation() {
  const [scrolled, setScrolled] = useState(false)
  const [menuOpen, setMenuOpen] = useState(false)

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 80)
    window.addEventListener('scroll', handler)
    return () => window.removeEventListener('scroll', handler)
  }, [])

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? 'shadow-lg shadow-black/20' : ''
      }`}
      style={{ background: 'var(--navy)' }}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-12 h-16 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex flex-col group">
          <span
            className="text-white font-medium tracking-[0.3em] text-sm"
            style={{ fontFamily: 'var(--font-dm-mono, monospace)' }}
          >
            S T I E M F I E L D
          </span>
          <span
            className="text-xs tracking-wide transition-colors duration-200"
            style={{ color: 'var(--teal-light, #14919B)', letterSpacing: '0.08em' }}
          >
            Global Convergence Firm
          </span>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-white/70 hover:text-white transition-colors duration-200 text-sm tracking-wide"
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            className="px-5 py-2 text-sm font-medium tracking-wide transition-all duration-200 rounded-sm"
            style={{
              background: 'var(--teal)',
              color: 'white',
            }}
            onMouseEnter={(e) =>
              ((e.target as HTMLElement).style.background = 'var(--teal-light)')
            }
            onMouseLeave={(e) =>
              ((e.target as HTMLElement).style.background = 'var(--teal)')
            }
          >
            Begin Scoping
          </Link>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden text-white p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Toggle menu"
        >
          {menuOpen ? <X size={22} /> : <Menu size={22} />}
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden absolute top-16 left-0 right-0 bottom-0 min-h-screen flex flex-col px-6 pt-8 gap-6"
          style={{ background: 'var(--navy-dark, #060F1D)' }}
        >
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="text-white/80 hover:text-white text-2xl transition-colors"
              style={{ fontFamily: 'var(--font-cormorant, serif)', fontWeight: 300 }}
              onClick={() => setMenuOpen(false)}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/contact"
            className="mt-4 px-6 py-3 text-center text-sm font-medium tracking-wide"
            style={{ background: 'var(--teal)', color: 'white' }}
            onClick={() => setMenuOpen(false)}
          >
            Begin Scoping
          </Link>
        </div>
      )}
    </nav>
  )
}
