# Stiemfield Website

**Global Convergence Firm — Rooted in Africa**

stiemfield.com | terungwa@stiemfield.com

---

## Tech Stack

- **Framework**: Next.js 14 (App Router)
- **Styling**: Tailwind CSS + CSS custom properties
- **Typography**: Cormorant Garamond (display) + DM Sans (body) + DM Mono (labels)
- **Deployment**: Vercel
- **Email**: Resend (contact form)
- **Analytics**: Vercel Analytics

---

## Getting Started

### 1. Clone and install

```bash
git clone https://github.com/pauldrizzy/stiemfield-website.git
cd stiemfield-website
npm install
```

### 2. Configure environment

```bash
cp .env.example .env.local
```

Edit `.env.local` and add your Resend API key:
- Sign up at [resend.com](https://resend.com)
- Create an API key
- Add it as `RESEND_API_KEY`

### 3. Run locally

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

---

## Deployment to Vercel

1. Push to GitHub
2. Go to [vercel.com/import](https://vercel.com/import)
3. Import the `pauldrizzy/stiemfield-website` repo
4. Add environment variable: `RESEND_API_KEY`
5. Deploy

### Custom domain (stiemfield.com)

In Vercel dashboard → Project Settings → Domains:
- Add `stiemfield.com`
- Add `www.stiemfield.com`
- Update DNS A record at your registrar to point to Vercel's IP

---

## Content Management

### Adding Insights articles

Articles live in `/content/insights/` as MDX files.

Create a new file: `YYYY-MM-DD-article-slug.mdx`

```mdx
---
title: "Your Article Title"
date: "2026-05-15"
pillar: "Strategy"
excerpt: "Two-sentence description of the article."
author: "Terungwa Paul Asar"
published: true
---

Your article content in Markdown here.
```

Available pillars: `Strategy`, `Technology`, `Innovation`, `Execution`, `Management`, `Methodology`, `Founder Voice`

### Adding your professional photo

Replace the placeholder in `components/sections/About.tsx`:
1. Add your photo to `/public/brand/terungwa-asar.jpg`
2. In `About.tsx`, replace the placeholder `<div>` with:
```tsx
import Image from 'next/image'
<Image
  src="/brand/terungwa-asar.jpg"
  alt="Terungwa Paul Asar, Founding Partner"
  fill
  className="object-cover"
/>
```

### Updating LinkedIn URL

Search for `linkedin.com/in/terungwa-asar` and replace with your actual LinkedIn profile URL.

---

## Brand Standards

**Colours**:
- Navy: `#0B1F3A`
- Teal: `#0D7377`
- Amber: `#F4A900`
- Slate: `#4A5568`
- Canvas: `#F8F9FA`

**Typography**:
- Display: Cormorant Garamond
- Body: DM Sans
- Labels/Mono: DM Mono

**Voice**: Authoritative, grounded, precise, warm. British English. Evidence before assertion.

**Never use**: holistic, synergies, best-in-class, seamless, game-changing, innovative solutions, end-to-end.

---

## Project Structure

```
/app
  /page.tsx              ← Home page
  /about/page.tsx
  /services/page.tsx
  /insights/page.tsx
  /contact/page.tsx
  /api/contact/route.ts  ← Form submission API
  /layout.tsx            ← Root layout + metadata
  /globals.css
  /sitemap.ts
  /robots.ts
/components
  /layout/
    Navigation.tsx
    Footer.tsx
  /sections/
    Hero.tsx
    STIEMFramework.tsx   ← Interactive pentagon
    GapPatterns.tsx
    Services.tsx
    About.tsx
    Geography.tsx
    InsightsPreview.tsx
    ContactForm.tsx
/content/insights/        ← MDX articles
```

---

## Quality Checklist

Before any public deployment:

- [ ] Professional photo added to About section
- [ ] LinkedIn URL updated to actual profile
- [ ] Resend API key configured
- [ ] `RESEND_API_KEY` set in Vercel environment variables
- [ ] Contact form tested end-to-end (email delivers to terungwa@stiemfield.com)
- [ ] Custom domain `stiemfield.com` connected in Vercel
- [ ] First 3 insights articles published (MDX files with `published: true`)
- [ ] OG image created and placed at `/public/og-image.png` (1200×630px)
- [ ] CAC RC Number added to Footer once received

---

*Stiemfield Consulting Limited · Incorporated in Nigeria · stiemfield.com*
